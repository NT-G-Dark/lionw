# LION - WHITE
Lion-White Đang Trong Quá Trình Test

Scr Này Chỉ Hoạt Động Trên Google Shell 

Lệnh :

- - - - - - - - - - - - - - - - - - - - - - - - -

git clone https://github.com/fuck0211/Lion-White/

pip3 install colorama

cd Lion-White

python3 main_end.py

- - - - - - - - - - - - - - - - - - - - - - - - - 

TOOL NÀY ANH EM TEST REQUESTS NÓ ĐÉO LÊN ĐÂU CỨ LẤY CAPCUT MAK TEST

Anh Em DDoS Thì Cứ Ngồi Mak Load Từ Từ R DIE 

Clip Test Tool (Sắp Có)



